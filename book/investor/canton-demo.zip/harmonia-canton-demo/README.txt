Harmonia recorded Canton demonstrations

1. Unzip this folder.
2. Open index.html in a browser. No installation or network is required.
3. Choose carousel stops, swipe, or use the arrow keys.

Export log saves the observations, visuals and your selected step as JSON.
Open open.html and choose that JSON to restore it, without the repository.
Evidence contains the original milestone mapping, inputs and expectations.

These are recorded local Canton runs, not new ledger submissions.
Run provenance and the exact renderer travel inside events.json.
The included marks identify Canton and Daml; they do not imply a partnership.
